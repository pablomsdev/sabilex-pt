TheInterior theme by FlexiThemes, https://flexithemes.com
Online Demo: https://flexithemes.com/demo/TheInterior/
Theme URI: https://flexithemes.com/theinterior-wordpress-theme/